function [ y ] = pdfOf2D(r0,rm)
y=-2/(rm^4*pi)*r0.^2+2/(rm^2*pi);
end

